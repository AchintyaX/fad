# Financial Anomaly Detection 

A Toolkit to perform anomaly detection on time-series data of any stock that can be download via yahoo finance API.

