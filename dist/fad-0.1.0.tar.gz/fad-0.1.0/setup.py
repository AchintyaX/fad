# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fad']

package_data = \
{'': ['*']}

install_requires = \
['adtk>=0.6.2,<0.7.0',
 'jupyter>=1.0.0,<2.0.0',
 'notebook>=6.4.12,<7.0.0',
 'pandas>=1.4.4,<2.0.0',
 'typing==3.5',
 'yfinance>=0.1.74,<0.2.0']

setup_kwargs = {
    'name': 'fad',
    'version': '0.1.0',
    'description': 'experimentation with anamoly detection',
    'long_description': '# Financial Anomaly Detection \n\nA Toolkit to perform anomaly detection on time-series data of any stock that can be download via yahoo finance API.\n\n',
    'author': 'Achintya Shankhdhar',
    'author_email': 'achintya.shankhdhar@simpplr.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
