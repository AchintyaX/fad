# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fad']

package_data = \
{'': ['*']}

install_requires = \
['adtk>=0.6.2,<0.7.0',
 'jupyter>=1.0.0,<2.0.0',
 'notebook>=6.4.12,<7.0.0',
 'pandas>=1.4.4,<2.0.0',
 'typing==3.5',
 'yfinance>=0.1.74,<0.2.0']

setup_kwargs = {
    'name': 'fad',
    'version': '0.1.1',
    'description': 'experimentation with anamoly detection',
    'long_description': "# Financial Anomaly Detection \n\nA Toolkit to perform anomaly detection on time-series data of any stock that can be download via yahoo finance API.\nYou can download the stock data and perform anomaly detection using a range of algorithms\n\n## Installation\nFor installing the pre-release version use -\n` pip install https://github.com/AchintyaX/fad/releases/download/v0.1.0/fad-0.1.0-py3-none-any.whl`\n\n## Usage\n1. fetch_data - Used for fetching stock data using yahoo finance API and transforming it for anamoly detection : \n```\nIn [1]: from fad import FinancialAnomalyDetector\n\nIn [2]: fad = FinancialAnomalyDetector()\n\nIn [3]: start = '2020-01-10'\n\nIn [4]: end = '2022-09-10'\n\nIn [5]: data = fad.fetch_data('SBIN.NS', start, end)\n\nIn [6]: data\nOut[6]:\n                  Open        High  ...   Adj Close      Volume\n2020-01-10  331.000000  337.950012  ...  324.151825  42377838.0\n2020-01-11  331.000000  337.950012  ...  324.151825  42377838.0\n2020-01-12  331.000000  337.950012  ...  324.151825  42377838.0\n2020-01-13  334.000000  335.450012  ...  322.688354  23615129.0\n2020-01-14  329.799988  331.700012  ...  320.005402  26296117.0\n...                ...         ...  ...         ...         ...\n2022-09-06  538.000000  542.700012  ...  537.799988   8657868.0\n2022-09-07  534.400024  537.450012  ...  532.849976   8445359.0\n2022-09-08  536.000000  546.299988  ...  544.650024  12240707.0\n2022-09-09  549.650024  557.000000  ...  553.349976  18585432.0\n2022-09-10  549.650024  557.000000  ...  553.349976  18585432.0\n\n[975 rows x 6 columns]\n\n```\n\n2. anamly_detection - Used to find anomalies in the data returning the dataframe along with plotting them in the time series\n\nThe package has 2 primary methods - \n1. \n\n## For Development \n\n1. Clone the project\n2. `pip install --upgrade pip`\n3. `pip install poetry`\n4. `poetry install`\n\nproject setup is complete for contributions \n\n",
    'author': 'Achintya Shankhdhar',
    'author_email': 'achintya.shankhdhar@simpplr.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
